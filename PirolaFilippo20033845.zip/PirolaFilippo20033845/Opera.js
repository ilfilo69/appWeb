'use strict'

class Opera{
    constructor(title,description,artist,year,price,image)
    {
        this.title=title;
        this.description=description;
        this.artist=artist;
        this.price=price;
        this.year=year;
        this.image=image;
    }
}

module.exports=Opera;