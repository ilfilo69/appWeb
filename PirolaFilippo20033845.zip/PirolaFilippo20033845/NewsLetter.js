'use strict'

class NewsLetter{
    constructor(email)
    {
        this.email=email;
    }
}

module.exports=NewsLetter;