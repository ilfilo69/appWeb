'use strict'
class News{
    constructor(month,description,file,year)
    {
        this.month=month;
        this.description=description;
        this.file=file;
        this.year=year;
    }
}

module.exports=News;